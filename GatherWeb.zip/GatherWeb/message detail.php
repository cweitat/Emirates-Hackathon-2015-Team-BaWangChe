<?php

require 'vendor/autoload.php';

session_start();
use Parse\ParseClient;

ParseClient::initialize('MGS5sYjgBDpFBj02X87izbUN3pkhWfAq86d2hRxu', 'y4cNtsR9wIDxmILApZE4z5wjSu4r4qxaz8HNxkAf', 'wwfO726xf6oAP22LgOej4HIRlWRyusW9mrhyV9Cp');

use Parse\ParseObject;
use Parse\ParseUser;
use Parse\ParseSessionStorage;
use Parse\ParseQuery;

$user = ParseUser::getCurrentUser();
if (!isset($user)) {
    Redirect('/GatherWeb/', false);
}
$div = "";
if(isset($_GET["userid"]))
{

    $query = ParseUser::query();
    $query->equalTo("username", $_GET["userid"]); 
    $results = $query->first();
    $name = $results->get('name');         



    $query = new ParseQuery("Message");
    $query->equalTo("Sender", $_GET["userid"]);
    $query->equalTo("Receipient", $user->get("username"));

    $AltQuery = new ParseQuery("Message");
    $AltQuery->equalTo("Receipient", $_GET["userid"]);
    $AltQuery->equalTo("Sender", $user->get("username"));

    $mainQuery = ParseQuery::orQueries([$query, $AltQuery]);
    $results = $mainQuery->find();

    $div = "<table>";
    
    for ($i = 0; $i < count($results); $i++) { 
        $object = $results[$i];
        if($object->get('Sender') == $_GET["userid"])
            $div .= "<tr><td>" . $name . " : " . $object->get('Message') . "</td></tr>";
        else
            $div .= "<tr><td>" . "You" . " : " . $object->get('Message') . "</td></tr>";
    }
    
    $div .= "</table>";
    // Do something with the returned ParseObject values
}else{
    $div = '<input type="text" placeholder="Receiver\' Admin ID" id="AdmID"/>';
}

if (isset($_POST['comment']) && isset($_POST['receiver'])) {
    $comment = $_POST['comment'];  
    $receiver = $_POST['receiver'];  

    $Message = new ParseObject("Message");

    $Message->set("Sender", $user->get("username"));
    $Message->set("Receipient", $receiver);
    $Message->set("Message", $comment);
    $Message->set("Read", false);
     
    try {
      $Message->save();
      echo 'New object created with objectId: ' . $Message->getObjectId();
    } catch (ParseException $ex) {  
      // Execute any logic that should take place if the save fails.
      // error is a ParseException object with an error code and message.
      echo 'Failed to create new object, with error message: ' + $ex->getMessage();
    }
}   
    
    
?>
<!DOCTYPE html>
<html>

    <head>
	<link rel="stylesheet" href="boilerplate.css">
	<link rel="stylesheet" href="message detail.css">
    <link rel="stylesheet" href="common.css">
	<meta charset="utf-8">
	<meta name="viewport" content="initial-scale = 1.0,maximum-scale = 1.0">
    <script>
        function submitComment(field)
        {
            if(document.getElementById("AdmID") !== null)
                document.getElementById("receiver").value = document.getElementById("AdmID").value;
            field.parentNode.submit();
        }
    </script>
    </head>
    <body>

    <div id="primaryContainer" class="primaryContainer clearfix">
        <div id="NavBar" class="clearfix">
            <p id="text">
            <a href="dashboard.html">
            Gather
            </a>
            </p>
            <p id="text1">
            <a href="dashboard.php">
            Dashboard
            </a>
            </p>
            <p id="text2">
            <a href="members.php">
            Members
            </a>
            </p>
            <p id="text3">
            <a href="message.php">
            Message
            </a>
            </p>
            <p id="text4">
            <a href="account.php">
            Account
            </a>
            </p>
            <input id="input" type="button" value="Sign out"></input>
        </div>
        <div id="Breadcrumbs" class="clearfix">
            <p id="text5">
            Dashboard
            </p>
            <p id="text6">
            &gt;
            </p>
            <p id="text7">
            Message
            </p>
            <p id="text8">
            &gt;
            </p>
            <p id="text9">
            Chat
            </p>
        </div>
        <div id="box" class="" style="width: 1000px;display: block;margin-left: auto;margin-right: auto;">

            <div id="box1" class="clearfix">
            <?php
                echo $div;
            ?>
            </div>
            <!-- <div id="box2" class="clearfix">
            asd
            </div> -->
            <div id="box3" class="clearfix" >
                <form method="post">
                <!-- <label id="formgroup"> -->
                    <!-- <p id="text13">
                    <br />
                    </p> -->
                    <textarea id="textinput" name="comment"></textarea>
                <!-- </label> -->
                <!-- <div id="box4" class="clearfix"> -->
                    <input type="hidden" name="receiver" id="receiver" value="<?php 
                        if(isset($_GET["userid"]))
                            echo $_GET["userid"];
                    ?>"/>
                    <input id="input1" type="button" onclick="submitComment(this);" value="Send"></input>
                <!-- </div> -->
                </form>
            </div>
        </div>
    </div>
    </body>
</html>