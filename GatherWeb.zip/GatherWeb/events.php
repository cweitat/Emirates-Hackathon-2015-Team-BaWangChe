<?php
require 'vendor/autoload.php';
session_start();
use Parse\ParseClient;
 
ParseClient::initialize('MGS5sYjgBDpFBj02X87izbUN3pkhWfAq86d2hRxu', 'y4cNtsR9wIDxmILApZE4z5wjSu4r4qxaz8HNxkAf', 'wwfO726xf6oAP22LgOej4HIRlWRyusW9mrhyV9Cp');

use Parse\ParseObject;
use Parse\ParseUser;

$user = ParseUser::getCurrentUser();
if (!isset($user)) {
    Redirect('/GatherWeb/', false);
}

if( isset($_POST['StartTime']) && 
    isset($_POST['EndTime']) && 
    isset($_POST['Name']) && 
    isset($_POST['Location']))
{
        $time = $_POST['StartTime'];
        $StartTime = DateTime::createFromFormat('d/m/Y H:i:s', $time);
        $time = $_POST['EndTime'];
        $EndTime = DateTime::createFromFormat('d/m/Y H:i:s', $time);

        $Name = $_POST['Name'];
        $Location = $_POST['Location'];  
        $Details = $_POST['Details'];  

        $Event = new ParseObject("Event");
 
        $Event->set("StartTime", $StartTime);
        $Event->set("EndTime", $EndTime);
        $Event->set("Name", $Name);
        $Event->set("Location", $Location);
        $Event->set("Details", $Details);
        $Event->set("Club",$user->get("username"));
         
        try {
          $Event->save();
          echo 'New object created with objectId: ' . $Event->getObjectId();
        } catch (ParseException $ex) {  
          // Execute any logic that should take place if the save fails.
          // error is a ParseException object with an error code and message.
          echo 'Failed to create new object, with error message: ' + $ex->getMessage();
        }
}

function Redirect($url, $permanent = false)
{
    header('Location: ' . $url, true, $permanent ? 301 : 302);
    exit();
}


?>
<!DOCTYPE html>
<html>

    <head>
	<link rel="stylesheet" href="boilerplate.css">
	<link rel="stylesheet" href="events.css">
    <link rel="stylesheet" href="common.css">
	<meta charset="utf-8">
	<meta name="viewport" content="initial-scale = 1.0,maximum-scale = 1.0">
    </head>
    <body>

    <div id="primaryContainer" class="primaryContainer clearfix">
        <div id="NavBar" class="clearfix">
            <p id="text">
            <a href="dashboard.html">
            Gather
            </a>
            </p>
            <p id="text1">
            <a href="dashboard.php">
            Dashboard
            </a>
            </p>
            <p id="text2">
            <a href="members.php">
            Members
            </a>
            </p>
            <p id="text3">
            <a href="message.php">
            Message
            </a>
            </p>
            <p id="text4">
            <a href="account.php">
            Account
            </a>
            </p>
            <input id="input" type="button" value="Sign out"></input>
        </div>
        <div id="Breadcrumbs" class="clearfix">
            <p id="text5">
            Dashboard
            </p>
            <p id="text6">
            &gt;
            </p>
            <p id="text7">
            Event
            </p>
        </div>
        <div id="box" class="clearfix">
        <form method="POST">
            <p id="text8">
            Name
            </p>
            <label id="formgroup">
                <p id="text9">
                <br />
                </p>
                <input id="textinput" type="text" name="Name" value=""></input>
            </label>
            <p id="text10">
            Location
            </p>
            <label id="formgroup1">
                <p id="text11">
                <br />
                </p>
                <input id="textinput1" type="text" name="Location" value=""></input>
            </label>
            <p id="text12">
            Starting Date
            </p>
            <label id="formgroup2">
                <p id="text13">
                <br />
                </p>
                <input type="text" name="StartTime" placeholder="DD/MM/YYYY HH:MM:SS"/>
            </label>
            <p id="text19">
            Ending Date
            </p>
            <label id="formgroup7">
                <p id="text20">
                <br />
                </p>
                <input type="text" name="EndTime" placeholder="DD/MM/YYYY HH:MM:SS"/>
            </label>
            <p id="text26">
            Details
            </p>
            <label id="formgroup12">
                <p id="text27">
                <br />
                </p>
                <textarea id="textinput2" name="Details" ></textarea>
            </label>
            <input type="submit" value="Submit"/>
            </form>
        </div>
    </div>
    </body>
</html>