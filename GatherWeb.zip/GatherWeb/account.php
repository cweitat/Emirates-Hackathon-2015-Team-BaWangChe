<!DOCTYPE html>
<html>

    <head>
	<link rel="stylesheet" href="boilerplate.css">
	<link rel="stylesheet" href="account.css">
    <link rel="stylesheet" href="common.css">
	<meta charset="utf-8">
	<meta name="viewport" content="initial-scale = 1.0,maximum-scale = 1.0">
    </head>
    <body>

    <div id="primaryContainer" class="primaryContainer clearfix">
        <div id="NavBar" class="clearfix">
            <p id="text">
            <a href="dashboard.html">
            Gather
            </a>
            </p>
            <p id="text1">
            <a href="dashboard.php">
            Dashboard
            </a>
            </p>
            <p id="text2">
            <a href="members.php">
            Members
            </a>
            </p>
            <p id="text3">
            <a href="message.php">
            Message
            </a>
            </p>
            <p id="text4">
            <a href="account.php">
            Account
            </a>
            </p>
            <input id="input" type="button" value="Sign out"></input>
        </div>
        <div id="Breadcrumbs" class="clearfix">
            <div id="text5">
            Dashboard
            </div>
            <div id="text6">
            &gt;
            </div>
            <div id="text7">
            Account
            </div>
        </div>
        <p id="text8">
        Current Password
        </p>
        <label id="formgroup">
            <p id="text9">
            <br />
            </p>
            <input id="textinput" type="text" value=""></input>
        </label>
        <p id="text10">
        New Password
        </p>
        <label id="formgroup1">
            <p id="text11">
            <br />
            </p>
            <input id="textinput1" type="text" value=""></input>
        </label>
        <p id="text12">
        Confirm Password
        </p>
        <label id="formgroup2">
            <p id="text13">
            <br />
            </p>
            <input id="textinput2" type="text" value=""></input>
        </label>
        <input id="input1" type="button" value="Submit"></input>
    </div>
    </body>
</html>