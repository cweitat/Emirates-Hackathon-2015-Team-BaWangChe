<?php
require 'vendor/autoload.php';

session_start();
use Parse\ParseClient;

ParseClient::initialize('MGS5sYjgBDpFBj02X87izbUN3pkhWfAq86d2hRxu', 'y4cNtsR9wIDxmILApZE4z5wjSu4r4qxaz8HNxkAf', 'wwfO726xf6oAP22LgOej4HIRlWRyusW9mrhyV9Cp');

use Parse\ParseObject;
use Parse\ParseUser;
use Parse\ParseSessionStorage;
use Parse\ParseQuery;

$user = ParseUser::getCurrentUser();
if (!isset($user)) {
    Redirect('/GatherWeb/', false);
}

    $query = new ParseQuery("Member");
    $query->equalTo("Club", $user->get("username"));
    $results = $query->find();
    echo "Successfully retrieved " . count($results) . " scores.";
    // Do something with the returned ParseObject values

if( isset($_POST['name']) && isset($_POST['value']))
{
        $Name = $_POST['name'];  
        $Value = $_POST['value'];  

        $Member = new ParseObject("Member");
 
        $Member->set("Name", $Name);
        $Member->set("AdmNo", $Value);
        $Member->set("Club",$user->get("username"));
         
        try {
          $Member->save();
          echo 'New object created with objectId: ' . $Member->getObjectId();
        } catch (ParseException $ex) {  
          // Execute any logic that should take place if the save fails.
          // error is a ParseException object with an error code and message.
          echo 'Failed to create new object, with error message: ' + $ex->getMessage();
        }
}

function Redirect($url, $permanent = false)
{
    header('Location: ' . $url, true, $permanent ? 301 : 302);
    exit();
}


?>
<!DOCTYPE html>
<html>

    <head>
	<link rel="stylesheet" href="boilerplate.css">
	<link rel="stylesheet" href="members.css">
    <link rel="stylesheet" href="common.css">
	<meta charset="utf-8">
	<meta name="viewport" content="initial-scale = 1.0,maximum-scale = 1.0">
    </head>
    <script>
        function addRow() {
            var div = document.createElement('form');
            div.method="POST";
            div.innerHTML = '<label> Name <input type="text" name="name" value="" />  </label>\
                <label> Admission number <input type="text" name="value" value="" /></label>\
                <input type="button" value="Submit" onclick="submitRow(this)">';

             document.getElementById("box").appendChild(div);
        }
        function submitRow(input) {
            input.parentNode.submit();
        }
    </script>
    <body>

    <div id="primaryContainer" class="primaryContainer clearfix">
        <div id="NavBar" class="clearfix">
            <p id="text">
            <a href="dashboard.html">
            Gather
            </a>
            </p>
            <p id="text1">
            <a href="dashboard.php">
            Dashboard
            </a>
            </p>
            <p id="text2">
            <a href="members.php">
            Members
            </a>
            </p>
            <p id="text3">
            <a href="message.php">
            Message
            </a>
            </p>
            <p id="text4">
            <a href="account.php">
            Account
            </a>
            </p>
            <input id="input" type="button" value="Sign out"></input>
        </div>
        <div id="Breadcrumbs" class="clearfix">
            <p id="text5">
            Dashboard
            </p>
            <p id="text6">
            &gt;
            </p>
            <p id="text7">
            Members
            </p>
        </div>
        <div id="box" class="clearfix">
            <input type="button" onclick="addRow();" value="New Member"/>
            <!-- <p i>
            Admission Number
            </p>
            <p >
            Name
            </p> -->
            <table>
                <thead>
                    <td id="text8" colspan="10">Name</td>
                    <td id="text9" colspan="10">Admission Number</td>
                    <td></td>
                </thead>
                <tbody>
                    <?php
                        for ($i = 0; $i < count($results); $i++) { 
                              $object = $results[$i];
                              echo "<tr><td>". $object->get('Name') . "</td><td>" . $object->get('AdmNo') . "</td></tr>";
                            }
                    ?>
                </tbody>
            </table>
        </div>
        <div id="Comments" class="clearfix">
            <p id="text10">
            Messages
            </p>
            <p id="text11">
            &#x23;
            </p>
            <p id="text12">
            Name
            </p>
        </div>
    </div>
    </body>
</html>