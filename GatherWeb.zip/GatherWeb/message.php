<?php

require 'vendor/autoload.php';

session_start();
use Parse\ParseClient;

ParseClient::initialize('MGS5sYjgBDpFBj02X87izbUN3pkhWfAq86d2hRxu', 'y4cNtsR9wIDxmILApZE4z5wjSu4r4qxaz8HNxkAf', 'wwfO726xf6oAP22LgOej4HIRlWRyusW9mrhyV9Cp');

use Parse\ParseObject;
use Parse\ParseUser;
use Parse\ParseSessionStorage;
use Parse\ParseQuery;

$user = ParseUser::getCurrentUser();
if (!isset($user)) {
    Redirect('/GatherWeb/', false);
}
    

    $query = new ParseQuery("Message");
    $query->equalTo("Receipient", $user->get("username"));
    $query->addDescending("Read");
    $results = $query->find();
    echo "Successfully retrieved " . count($results) . " scores.";
    // Do something with the returned ParseObject values

?>


<!DOCTYPE html>
<html>

    <head>
	<link rel="stylesheet" href="boilerplate.css">
	<link rel="stylesheet" href="message.css">
    <link rel="stylesheet" href="common.css">
	<meta charset="utf-8">
	<meta name="viewport" content="initial-scale = 1.0,maximum-scale = 1.0">
    </head>
    <body>

    <div id="primaryContainer" class="primaryContainer clearfix">
        <div id="NavBar" class="clearfix">
            <p id="text">
            <a href="dashboard.html">
            Gather
            </a>
            </p>
            <p id="text1">
            <a href="dashboard.php">
            Dashboard
            </a>
            </p>
            <p id="text2">
            <a href="members.php">
            Members
            </a>
            </p>
            <p id="text3">
            <a href="message.php">
            Message
            </a>
            </p>
            <p id="text4">
            <a href="account.php">
            Account
            </a>
            </p>
            <input id="input" type="button" value="Sign out"></input>
        </div>
        <div id="Breadcrumbs" class="clearfix">
            <p id="text5">
            Dashboard
            </p>
            <p id="text6">
            &gt;
            </p>
            <p id="text7">
            Messages
            </p>
        </div>
        <div id="box" class="clearfix">
        <a href="message%20detail.php">New Message</a>
            <table>
                <thead>
                    <td>#</td>
                    <td>Name</td>
                    <td>Message</td>
                </thead>
                <tbody>
                    <?php
                        $sender = [];
                        $amount = [];
                        $message = [];
                        for ($i = 0; $i < count($results); $i++) { 
                          $inList = false;  
                          $counter = -1;
                          $object = $results[$i];

                          for($count = 0; $count < count($sender); $count++){
                            if($sender[$count] == $object->get('Sender')){
                                $inList = true;
                                $counter = $count;
                                break;
                            }
                          }

                          if($inList){
                            if($object->get('Read'))
                                $amount[$counter] += 1;
                            $message[$counter] = $object->get('Message');
                          }else{
                            array_push($sender, $object->get('Sender'));
                            if($object->get('Read'))
                                array_push($amount, 1);
                            else
                                array_push($amount, 0);
                            array_push($message, $object->get('Message'));
                          }

                        }

                        $senderName = [];
                        for($count = 0; $count < count($sender); $count++){
                            $query = ParseUser::query();
                            $query->equalTo("username", $sender[$count]); 
                            $results = $query->first();
                            array_push($senderName, $results->get('name'));
                        }

                        for($count = 0; $count < count($sender); $count++){
                            $href =  '<a href="message%20detail.php?userid=' . $sender[$count] . '">';
                            echo  '<tr><td>';
                            echo  $href . $amount[$count] . '</a>';
                            echo  "</td><td>" ;
                            echo  $href . $senderName[$count] . '</a>' ;
                            echo  "</td><td>" . $href . $message[$count]  . '</a>';
                            echo  "</td></tr></a>";
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    </body>
</html>