<?php

require 'vendor/autoload.php';
session_start();

use Parse\ParseClient;

ParseClient::initialize('MGS5sYjgBDpFBj02X87izbUN3pkhWfAq86d2hRxu', 'y4cNtsR9wIDxmILApZE4z5wjSu4r4qxaz8HNxkAf', 'wwfO726xf6oAP22LgOej4HIRlWRyusW9mrhyV9Cp');

use Parse\ParseUser;

$user = ParseUser::getCurrentUser();
if (isset($user) && $user->get("MemType")) {
    Redirect('/GatherWeb/dashboard.php', false);
}else
{
    ParseUser::logOut();
    echo "Only Admin account accepted";
}

if( isset($_POST['email']) && 
    isset($_POST['password']))
{

        try {
            $email = $_POST['email'];
            $password = $_POST['password'];
            $user = ParseUser::logIn($email, $password);
            $user = ParseUser::getCurrentUser();
            if($user->get("MemType"))
                Redirect('/GatherWeb/dashboard.php', false);
            else{
                ParseUser::logOut();
                echo "Only Admin account accepted";
            }
            // Do stuff after successful login.
        } catch (ParseException $error) {
            // The login failed. Check error to see why.
            echo $error;
        } catch (Exception $error)  {
            echo $error;
        }
}

function Redirect($url, $permanent = false)
{
    header('Location: ' . $url, true, $permanent ? 301 : 302);
    exit();
}


?>
<!DOCTYPE html>
<html>

    <head>
	<link rel="stylesheet" href="boilerplate.css">
	<link rel="stylesheet" href="login.css">
    <link rel="stylesheet" href="common.css">
	<meta charset="utf-8">
	<meta name="viewport" content="initial-scale = 1.0,maximum-scale = 1.0">
    </head>
    <body>

    <div id="primaryContainer" class="primaryContainer clearfix">
        <div id="box" class="clearfix">
            <p id="text">
            Gather
            </p>
        </div>
        <div id="box1" class="clearfix">
            <form method="POST">
            <p id="text1">
                Email
            </p>
            <label id="formgroup">
            <input id="textinput" type="email" name="email" value=""></input>
            </label>
            <p id="text3">
            &#x40;cca.sg
            </p>
            <p id="text4">
            Password
            </p>
            <label id="formgroup1">
            <input id="textinput1" type="password" name="password" value=""></input>
            </label>
            <a href="signup.php"><input id="input" type="button" value="Signup"></input></a>
            <input id="input1" type="submit" value="Login"></input>
            </form>
        </div>
    </div>
    </body>
</html>