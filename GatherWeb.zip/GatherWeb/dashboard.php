<?php

require 'vendor/autoload.php';
session_start();
use Parse\ParseClient;
 
ParseClient::initialize('MGS5sYjgBDpFBj02X87izbUN3pkhWfAq86d2hRxu', 'y4cNtsR9wIDxmILApZE4z5wjSu4r4qxaz8HNxkAf', 'wwfO726xf6oAP22LgOej4HIRlWRyusW9mrhyV9Cp');

use Parse\ParseObject;
use Parse\ParseUser;
use Parse\ParseQuery;

$user = ParseUser::getCurrentUser();
if (!isset($user)) {
    Redirect('/GatherWeb/', false);
}
    $query = new ParseQuery("Event");
    $query->equalTo("Club", $user->get("username"));
    $results = $query->find();
    echo "Successfully retrieved " . count($results) . " scores.";
    // Do something with the returned ParseObject values
    
?>
<!DOCTYPE html>
<html>

    <head>
	<link rel="stylesheet" href="boilerplate.css">
	<link rel="stylesheet" href="dashboard.css">
    <link rel="stylesheet" href="common.css">
	<meta charset="utf-8">
	<meta name="viewport" content="initial-scale = 1.0,maximum-scale = 1.0">
    <style>
        tr{
            margin-bottom:50px;
        }
    </style>
    </head>
    <body>

    <div id="primaryContainer" class="primaryContainer clearfix">
        <div id="NavBar" class="clearfix">
            <p id="text">
            <a href="dashboard.html">
            Gather
            </a>
            </p>
            <p id="text1">
            <a href="dashboard.php">
            Dashboard
            </a>
            </p>
            <p id="text2">
            <a href="members.php">
            Members
            </a>
            </p>
            <p id="text3">
            <a href="message.php">
            Message
            </a>
            </p>
            <p id="text4">
            <a href="account.php">
            Account
            </a>
            </p>
            <input id="input" type="button" value="Sign out"></input>
        </div>
        <div id="Breadcrumbs" class="clearfix">
            <p id="text5">
            Dashboard
            </p>
        </div>
        <div id="Container" class="clearfix">
            <div id="box" class="clearfix">
                <input id="input1" type="button" value="This Week"></input>
                <input id="input2" type="button" value="Next Week"></input>
                <input id="input3" type="button" value="Upcoming"></input>
                <div id="Table" class="clearfix">
                    <a href="events.php">New Events</a>
                    <table>
                        <thead>
                            <tr>
                                <td colspan="10">Event</td>
                                <td>Attendance</td>
                                <td></td>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                            for ($i = 0; $i < count($results); $i++) { 
                              $object = $results[$i];
                              echo "<tr><td>". $object->get('Name') . "<br>". $object->get('Location') . "<br>". $object->get('StartTime')->format('d-m-Y H:i:s') . "<br>". $object->get('EndTime')->format('d-m-Y H:i:s') . "<br>";
                              echo "<td><tr>";
                            }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div id="box1" class="clearfix">
                <div id="Comments" class="clearfix">
                    <p id="text6">
                    Messages
                    </p>
                    <p id="text7">
                    &#x23;
                    </p>
                    <p id="text8">
                    Name
                    </p>
                </div>
                <div id="Shortcuts" class="clearfix">
                    <p id="text9">
                    Shortcuts
                    </p>
                    <p id="text10">
                    Add Members
                    </p>
                    <p id="text11">
                    Show Events<br />
                    </p>
                </div>
            </div>
        </div>
    </div>
    </body>
</html>