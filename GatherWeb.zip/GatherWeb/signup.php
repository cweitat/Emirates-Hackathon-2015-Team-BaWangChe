<?php

require 'vendor/autoload.php';
 
use Parse\ParseClient;
 
ParseClient::initialize('MGS5sYjgBDpFBj02X87izbUN3pkhWfAq86d2hRxu', 'y4cNtsR9wIDxmILApZE4z5wjSu4r4qxaz8HNxkAf', 'wwfO726xf6oAP22LgOej4HIRlWRyusW9mrhyV9Cp');

use Parse\ParseUser;

if( isset($_POST['email']) && 
    isset($_POST['password']) && 
    isset($_POST['name']) && 
    isset($_POST['code']))
{

        $email = $_POST['email'];
        $password = $_POST['password'];  
        $name = $_POST['name'];
        $code = $_POST['code'];

        $user = new ParseUser();
        $user->set("username", $email);
        $user->set("email", $email);
        $user->set("password", $password);
        $user->set("name",$name);
        $user->set("MemType", true);
            
        if($code == "ABCD"){
            try {
                  $user->signUp();
                  // Hooray! Let them use the app now.
                  echo "Sign up successful";
                  Redirect('/GatherWeb/index.php', false);
                } catch (ParseException $ex) {
                  // Show the error message somewhere and let the user try again.
                  echo "Error: " . $ex->getCode() . " " . $ex->getMessage();
                }
        }
}

function Redirect($url, $permanent = false)
{
    header('Location: ' . $url, true, $permanent ? 301 : 302);
    exit();
}


?>

<!DOCTYPE html>
<html>

    <head>
	<link rel="stylesheet" href="boilerplate.css">
    <link rel="stylesheet" href="common.css">
	<link rel="stylesheet" href="signup.css">
    
	<meta charset="utf-8">
	<meta name="viewport" content="initial-scale = 1.0,maximum-scale = 1.0">
    </head>
    <body>

    <div id="primaryContainer" class="primaryContainer clearfix">
        <div id="box" class="clearfix">
            <p id="text">
            Gather
            </p>
        </div>
        <div id="box1" class="clearfix">
            <form method="POST">
            <label id="formgroup">
                <p id="text1">
                Email
                </p>
                <input id="textinput" name="email" type="email" value=""></input>
            </label>
            <label id="formgroup1">
                <p id="text2">
                Password
                </p>
                <input id="textinput1" type="password" name="password" value=""></input>
            </label>
            <label id="formgroup2">
                <p id="text3">
                Club Name
                </p>
                <input id="textinput2" type="text" name="name" value=""></input>
            </label>
            <label id="formgroup3">
                <p id="text4">
                Confirmation Code
                </p>
                <input id="textinput3" type="text" name="code" value=""></input>
            </label>
            <input id="input" type="submit" value="Submit"></input>
            </form>
        </div>
    </div>
    </body>
</html>